# -*- coding: utf-8 -*-
"""멘토 발표 v2 — 정적 페이지(PDF처럼). 장 제목은 결론 문장, 한 장에 주장 하나 + 근거 그림 하나. 숫자는 facts.md 에 있는 것만."""
import sys
from pathlib import Path
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path(__file__).parent))
from svgkit import Flow

OUT = Path(r"C:\Users\playdata2\Documents\final_workspace\program\산출물양식\w4\멘토발표_2026-10-02\v2\index.html")
A = "../assets/"
P = []


def page(title, body, kicker="", src="", cls=""):
    k = f'<div class="kicker">{kicker}</div>' if kicker else ""
    s = f'<div class="src">{src}</div>' if src else ""
    P.append(f'<section class="page {cls}">{k}<h2>{title}</h2><div class="body">{body}</div>{s}</section>')


def phone(img, cap="", w=240):
    h = int(w * 2.16)
    c = f'<div class="cap">{cap}</div>' if cap else ""
    return f'<div class="ph"><div class="phone" style="width:{w}px;height:{h}px"><img src="{A}{img}" alt=""></div>{c}</div>'


def num(v, unit, label, sub="", color=""):
    return (f'<div class="numc"><div class="n {color}">{v}<span>{unit}</span></div><div class="nl">{label}</div>'
            + (f'<div class="ns">{sub}</div>' if sub else "") + "</div>")


ARROW = '<div class="arw">→</div>'

# 1 표지 ----------------------------------------------------------------
P.append(f'''<section class="page cover">
<div class="row" style="height:100%;align-items:center;gap:70px">
 <div style="flex:1"><div class="kicker">A-COPilot · 멘토링 2026-10-02</div>
  <h1>여행 계획을 받아,<br><span class="hl">여행이 끝날 때까지 지키는</span><br>에이전트 triPilot</h1>
  <p class="lead">외국인 자유여행자 · 서울 · 최대 7일 · 4인</p></div>
 <div class="row" style="gap:24px;align-items:flex-end">{phone("s1_home.jpg", w=220)}<div style="margin-bottom:50px">{phone("s3_choice.jpg", w=240)}</div></div>
</div></section>''')

# 2 숫자 고리 ------------------------------------------------------------
page("외국인 여행자 대부분은 가이드 없이 직접 일정을 관리하고,<br>그 계획은 현지에서 자주 깨집니다",
     f'''<div class="chain">
  <div class="link"><div class="q">누가 관리하나</div>{num("82.9", "%", "개별여행 비중", "가이드 없이 스스로 일정 관리")}</div>{ARROW}
  <div class="link"><div class="q">얼마나 깨지나</div>{num("42.5", "%", "현지에서 일정을 바꿈", "짠 계획이 여행 중 바뀐다", "warn")}</div>{ARROW}
  <div class="link"><div class="q">깨지면 무엇을 하나</div>{num("96.4", "%", "현지에서 정보를 다시 검색", "혼자 다시 찾아 다시 짠다")}</div>{ARROW}
  <div class="link"><div class="q">그 결과</div><div class="numc"><div class="n warn">84.6<span>%</span> → 70.8<span>%</span></div><div class="nl">만족도, 여행 전 → 현장</div><div class="ns">14%p 떨어진다</div></div></div>
</div>
<p class="say">계획을 세우는 일보다, <b>여행 중에 깨진 계획을 다시 맞추는 일</b>이 여행자에게 남겨져 있습니다.</p>''',
     "문제 ① 계획은 깨진다", "출처: 개별여행 82.9%(2025년 1분기, 문체부 외래관광객조사 · 야놀자리서치 558), 현지 재검색·일정 변경·만족도(야놀자리서치, 중간발표 자료)")

# 3 왜 한국에서 더 어렵나 ----------------------------------------------------
nine = ["문제 발견", "검색", "번역", "영업 확인", "대안 찾기", "이동 다시 계산", "예약 충돌 확인", "일정 고치기", "동행자에게 공유"]
steps = "".join(f'<div class="st"><b>{i + 1}</b>{t}</div>' for i, t in enumerate(nine))
page("한국에서는 예약·지도·결제 정보에 닿기 어려워,<br>깨진 계획을 혼자 복구하는 데 아홉 단계가 듭니다",
     f'''<div class="row" style="gap:40px;align-items:stretch">
  <div class="card" style="width:430px">
    <div class="q">왜 한국에서 더 어렵나</div>
    <div class="row" style="gap:34px;margin:14px 0 8px"><div>{num("11", "%", "한국")}</div><div>{num("7", "%", "일본", color="grayc")}</div></div>
    <div class="ns" style="font-size:20px">여행 불편을 말한 비율. 한국은 <b>예약 · 지도 검색 · 결제</b> 단계에서 막힌다</div>
    <div class="ns" style="font-size:20px;margin-top:14px">언어소통 어려움 26.6%</div>
  </div>
  <div style="flex:1">
    <div class="q">예: 1시에 예약한 식당이 임시휴무, 3시엔 체험 예약이 있다면</div>
    <div class="nine">{steps}</div>
    <p class="say" style="margin-top:22px">triPilot이 대신하는 것이 바로 <b>이 아홉 단계</b>입니다.</p>
  </div>
</div>''', "문제 ② 복구가 어렵다", "출처: 불편 언급 한국 11% vs 일본 7%(야놀자리서치 2026-05 보도), 언어소통 어려움 26.6%(대한상공회의소 조사, KDI 경제정보센터). 9단계는 팀 인트로 근거 문서의 정리.")

# 4 페르소나 ------------------------------------------------------------------
tl = [("09:00", "경복궁", None), ("12:00", "성수 점심", ("식당 임시휴무", "요식")), ("15:00", "잠실 전망대", ("미세먼지·소나기 경보", "액티비티")), ("22:30", "숙소로", ("역 무정차 · 막차", "이동"))]
cols = ""
for t, p, ev in tl:
    e = (f'<div class="ev"><div class="evt">{ev[0]}</div><div class="ns">→ {ev[1]} 에이전트가 먼저 확인</div></div>' if ev else '<div class="ev ok"><div class="ns">문제 없음</div></div>')
    cols += f'<div class="tl"><div class="tt">{t}</div><div class="tp">{p}</div><div class="dot"></div>{e}</div>'
page("서울에 처음 온 대만인 친구 두 명의 하루에서도<br>계획은 세 번 깨질 수 있습니다",
     f'''<div class="row" style="gap:40px;align-items:center;margin-bottom:34px">
  <div class="card dark" style="width:460px"><div class="ns" style="color:#cfe3d6">대표 고객 (예시 인물)</div><div style="font-size:36px;font-weight:800;margin:8px 0">대만인 친구 2명</div>
   <div style="font-size:21px;line-height:1.6">K-콘텐츠로 온 첫 서울 · 한국어 못함<br>쇼핑·맛집 자유여행 · 앱 여러 개를 오감</div></div>
  <p class="say" style="flex:1;margin:0">계획은 이미 <b>본인이 다 짰습니다</b>. 문제는 여행 <b class="warn">중에</b> 깨질 때입니다.</p>
</div><div class="timeline">{cols}</div>''', "누구의 문제인가", "사건은 계획서 v11 §8-A 대표 시연 시나리오의 사건 6개(기상 · 역 화재 무정차 · 70분 지연 · 구역 통제 · 임시휴무 · 품절) 중 셋을 골랐다.")

# 5 해결 -------------------------------------------------------------------------
three = [("올린다", "쓰던 계획을 그대로 올리면 일정으로 읽어 등록", "s2_upload.jpg"),
         ("지킨다", "식당·활동·이동을 여행 내내 다시 확인", "s4_schedule.jpg"),
         ("알린다", "먼저 고쳐 두고, 다른 안을 함께 알림", "s5_alerts.jpg")]
c3 = "".join(f'<div class="card f3"><div class="t3">{t}</div><div class="d3">{d}</div>{phone(i, w=170)}</div>' for t, d, i in three)
page("그래서 triPilot은 계획을 새로 짜는 앱이 아니라,<br>이미 있는 계획을 받아 여행 내내 지킵니다",
     f'<div class="row" style="gap:26px">{c3}</div><p class="ns" style="margin-top:18px;font-size:19px">계획이 없으면 짜 주기도 합니다(서울 3일 2인 요청 → 후보 1,779곳 중 12곳을 골라 등록).</p>',
     "해결")

# 6 비교 ------------------------------------------------------------------------
rows = [("TripIt Pro", "항공편", "항공 지연·취소 알림", "식당·활동 영향 검증은 확인 못 함", "연 $49"),
        ("TripMazer", "여행 일정", "날씨·파업·지연 감시, 재계획", "AI 제안은 약관상 추정치", "—"),
        ("Tripsy", "여행 일정", "일정 편집(API)", "자동 감지→재제안 흐름은 확인 못 함", "—"),
        ("토모트래블 (사람)", "여행 전 설계", "사람이 상담·설계", "여행 중 실시간 확인은 확인 못 함", "29,000~249,000원"),
        ("triPilot", "내 계획 전체", "식당·활동·이동을 스스로 재확인", "먼저 고치고 다른 안 3개 + 알림", "팀당 49,000원")]
tr = "".join(f'<tr class="{"me" if r[0] == "triPilot" else ""}">' + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows)
page("비슷한 서비스는 항공 알림이나 사전 설계에 머물고,<br>여행 중 식당·활동·이동을 함께 다시 확인하는 곳은 찾지 못했습니다",
     f'<table class="cmp"><thead><tr><th>서비스</th><th>무엇을 지키나</th><th>하는 것</th><th>여행 중 문제가 생기면</th><th>가격</th></tr></thead><tbody>{tr}</tbody></table>'
     '<p class="ns" style="margin-top:16px;font-size:19px">「확인 못 함」은 기능이 없다는 뜻이 아니라, 공개 자료와 팀의 직접 시험에서 확인하지 못했다는 뜻입니다. '
     '팀 시험 사례: KAYAK은 추석 롯데마트 서울역점 휴무를 몰랐고, Tripomatic은 트릭아이미술관 영업시간이 틀렸습니다.</p>',
     "무엇이 다른가")

# 7·8 유스케이스 -----------------------------------------------------------------
page("사용자는 로그인 없이 쓰던 계획을 붙여 넣고,<br>읽힌 항목을 확인한 뒤 등록합니다",
     f'''<div class="row" style="gap:30px;justify-content:center;align-items:flex-start">
 {phone("s1_home.jpg", "① 첫 화면<br>언어 선택 · 내 여행", 230)}
 <div class="card mini"><div class="t3" style="font-size:26px">② 설문 6문항</div><div class="ns">테마 · 누구와 · 우선순위 · 실내/실외 · 여유<br><b>일정이 꼬이면: 바꿔 줘 / 먼저 물어봐</b></div></div>
 {phone("s2_upload.jpg", "③ 계획 붙여 넣기<br>글 · 사진 · 파일 5개까지", 230)}
 <div class="col" style="width:300px;gap:16px"><div class="card mini" style="width:auto"><div class="t3" style="font-size:26px">④ 함께 확인</div><div class="ns">읽은 항목마다 근거 표시<br>고치기 · 빼기 → 등록</div></div>
 <div class="card mini" style="width:auto;background:#e5efe8"><div class="t3" style="font-size:24px">등록 즉시</div><div class="ns">디스코드 알림 + 로그인 없이 열리는 여행계획서 링크(늘 최신)</div></div></div>
</div>''', "유스케이스 ① 여행 전", "실제 화면 캡처(2026-10-01, 개발 중인 서비스). 이메일은 복구용으로만 받고 저장하지 않는다.")

page("여행 중 문제가 생기면 triPilot이 먼저 고쳐 두고,<br>다른 안을 함께 알립니다",
     f'''<div class="row" style="gap:26px;justify-content:center">
 {phone("s3_choice.jpg", "선택이 필요해요<br>먼저 바꾼 안 + 다른 안 3개", 196)}
 {phone("s5_alerts.jpg", "받은 알림<br>변경 · 선택 요청 · 출발 안내", 196)}
 {phone("s6_map.jpg", "지도<br>일차별 번호 핀", 196)}
 {phone("s7_chat.jpg", "채팅<br>하루 요약 · 다음 이동", 196)}
</div>
<div class="quote">「요청하신 대로 페스타 바이 중후 대신 서울다이닝(으)로 바꿨습니다(12:00 시작). 다른 안: 1) 필동면옥 · 2) 평안도족발집 · 3) 12:30으로 늦추면 송원. <b>답이 없으면 지금대로 둡니다.</b>」</div>''',
     "유스케이스 ② 여행 중", "실제 화면과 실제 알림 문구. 알림은 승인 요청이 아니다 — 알림을 못 봐도 여행계획서 링크가 늘 최신이다.")

# 9 LLM vs 에이전트 --------------------------------------------------------------
f = Flow(1420, 430)
f.node("q", 40, 150, 200, 90, "질문", "ghost", 0, 24)
f.node("a", 330, 150, 200, 90, "답 한 번", "ghost", 0, 24)
f.edge("q", "a")
f.label(40, 300, "시각을 스스로 모름 · 틀려도 확인 안 함", 19, "#8a938d")
f.label(40, 60, "LLM 호출", 30, "#6f7872", weight=800)
f.label(640, 22, "에이전트", 30, "#2d5f48", weight=800)
loop = [("w", 680, 50, "① 정해진 때에 깨어남", "trig"), ("t", 1030, 50, "② 일감 받기\n무슨 일 · 지킬 것 · 도구", "proc"),
        ("c", 1110, 200, "③ 조회\n시간표 · 영업시간 · API", "dec"), ("j", 1030, 330, "④ 따져 보기 (최대 6단계)", "proc"),
        ("act", 680, 330, "⑤ 행동\n일정 새 판 · 알림", "out"), ("m", 600, 190, "⑥ 결과를 남기고\n다음 때를 기다림", "agent")]
for k, x, y, t, kd in loop:
    f.node(k, x, y, 300 if k != "c" else 290, 80, t, kd, 0, 20)
f.edge("w", "t"); f.edge("t", "c", "r", "t"); f.edge("c", "j", "b", "r"); f.edge("j", "act", "l", "r"); f.edge("act", "m", "l", "b"); f.edge("m", "w", "t", "l")
page("이것이 가능한 이유는, 묻는 말에 한 번 답하는 LLM이 아니라<br>스스로 확인하고 결과를 남기는 에이전트이기 때문입니다",
     f'<div style="height:440px">{f.svg()}</div><div class="quote gold"><b>원칙: 판정은 코드가, 말은 LLM이.</b> 시각·영업시간·막차는 시간표와 데이터로 계산하고 LLM이 짓지 않습니다.</div>',
     "LLM 호출과 에이전트의 차이")

# 10 사람 팀 -----------------------------------------------------------------
people = [("계획 읽기", "여행사 접수 담당", "받은 계획서를 한 줄씩 옮겨 적고, 모호한 것만 묻는다"),
          ("요식", "맛집 컨시어지", "영업·브레이크·라스트오더를 확인하고, 대신 갈 곳을 고른다"),
          ("액티비티", "현지 가이드", "휴무·날씨를 보고 비슷한 활동으로 바꾼다"),
          ("이동", "교통 안내원", "시간표로 제시간 도착을 계산하고 막차를 챙긴다")]
pc = "".join(f'<div class="card"><span class="pill">{n} 에이전트</span><div class="t3" style="margin:12px 0 6px">{p}</div><div class="ns" style="color:#1d2a23">{d}</div></div>' for n, p, d in people)
page("사람이 하던 여행 관리를<br>매니저 한 명과 전문가 네 명의 역할로 나눴습니다",
     f'''<div class="row" style="gap:30px;align-items:center">
 <div class="card dark" style="width:360px;text-align:center;padding:40px 26px"><div class="ns" style="color:#cfe3d6">코어</div><div style="font-size:40px;font-weight:800;margin:8px 0">여행 매니저</div>
  <div style="font-size:20px;line-height:1.6">언제 볼지 정하고, 누구에게 맡길지 고르고,<br>결과를 확인해 일정에 반영하고 알린다</div></div>
 <div style="flex:1;display:grid;grid-template-columns:1fr 1fr;gap:20px">{pc}</div></div>
<p class="ns" style="margin-top:22px;font-size:19px">전문 에이전트끼리는 직접 부르지 않고 매니저를 거칩니다. 누가 무엇을 바꿨는지가 한 곳에 남습니다.</p>''',
     "에이전트 = 여행 매니저 팀")

# 11 트리거 4 · 알림 3 ----------------------------------------------------------
tg = Flow(1440, 555)
trig = [("일정 생성 · 변경", "새로 등록하거나 고쳤을 때"), ("사용자 요청", "채팅·신고로 바꿔 달라고 할 때"), ("새벽 3시 자동 점검", "그날부터의 일정을 미리 확인"), ("인터럽트", "재난 · 기상이변 등 돌발 상황")]
for i, (a, b) in enumerate(trig):
    tg.node(f"t{i}", 0, 20 + i * 132, 330, 104, f"{a}\n{b}", "trig", 0, 21)
tg.node("core", 450, 170, 420, 200, "일정 조정\n(매니저 + 에이전트가 점검하고\n필요하면 바꾼다)", "out", 0, 24)
for i in range(4):
    tg.edge(f"t{i}", "core")
al = [("시스템에 의한 변동", "자동 점검·인터럽트로 바꾼 결과"), ("사용자 요청에 의한 변동", "요청대로 바꾼 결과 + 다른 안"), ("일정 알림", "하루 시작 · 다음 일정 · 출발 시각")]
for i, (a, b) in enumerate(al):
    tg.node(f"a{i}", 1040, 40 + i * 170, 400, 120, f"{a}\n{b}", "agent", 0, 21)
tg.edge("core", "a0"); tg.edge("core", "a1")
tg.label(1040, 540, "일정 알림은 조정과 별개로, 일정에 맞춰 나갑니다", 18, "#5f6b64")
page("일정 조정은 네 가지 때에 시작되고,<br>사용자에게는 세 가지 알림이 갑니다",
     f'<div class="row" style="gap:0;font-size:22px;font-weight:800;color:#5f6b64;margin-bottom:6px"><div style="width:470px">언제 시작되나</div><div style="width:590px"></div><div>사용자가 받는 알림</div></div><div style="height:560px">{tg.svg()}</div><div class="quote" style="margin-top:6px">하루 시작·종료 시각은 트리거가 아닙니다. 일정을 짜 주거나 조정할 때 그 범위를 넘지 않도록 참고하는 기준입니다.</div>',
     "트리거와 알림")

# 12 공동 플로우 ------------------------------------------------------------------
g = Flow(1440, 560)
g.node("rng", 0, 200, 220, 110, "확인 범위 고르기\n바로 다음 · 오늘 남은 일정\n· 이후 전부", "dec", 0, 19)
g.node("pick", 270, 210, 200, 90, "점검할 식당·장소\n추리기", "proc", 0, 19)
g.edge("rng", "pick")
ag = [("요식", "영업·브레이크·라스트오더"), ("액티비티", "휴무·운영시간·날씨"), ("이동", "제시간·막차·환승")]
for i, (n, d) in enumerate(ag):
    g.node(f"a{i}", 520, 70 + i * 145, 240, 100, f"{n} 에이전트\n{d}", "agent", 0, 19)
    g.edge("pick", f"a{i}")
g.node("db", 810, 150, 180, 80, "데이터 조회", "proc", 0, 20)
g.node("alt", 810, 290, 180, 110, "실패하면\n다른 소스로\n그래도 없으면 「확인 필요」", "fail", 0, 17)
for i in range(3):
    g.edge(f"a{i}", "db")
g.edge("db", "alt", "b", "t")
g.node("q", 1040, 150, 170, 80, "방문에 문제?", "dec", 0, 20)
g.edge("db", "q")
g.node("keep", 1040, 20, 170, 66, "그대로 유지", "ghost", 0, 19)
g.edge("q", "keep", "t", "b", text="없음")
g.node("rep", 1040, 300, 170, 140, "대신할 곳 고르기\n1 비슷한 곳\n2 취향 반영\n3 가까운 곳", "proc", 0, 18)
g.edge("q", "rep", "b", "t", text="있음")
g.node("apply", 1260, 150, 180, 120, "허용 범위 안이면\n먼저 적용\n아니면 승인 요청", "out", 0, 18)
g.node("tell", 1260, 330, 180, 90, "알림 ·\n여행계획서 갱신", "out", 0, 19)
g.edge("rep", "apply"); g.edge("apply", "tell", "b", "t")
page("어떤 때에 시작되든 에이전트들은 같은 순서로<br>점검하고, 대신할 곳을 고르고, 알립니다",
     f'<div style="height:570px">{g.svg()}</div>', "에이전트 공동 플로우",
     "팀 피그마 「액티비티&요식업 공통플로우」를 정리. 조회가 끝까지 실패하면 조용히 넘기지 않고 「확인 필요」로 알린다.")


# 13~16 에이전트별 -----------------------------------------------------------------
def agent_page(kicker, title, nodes, edges, side, src="", h=470):
    fl = Flow(960, h)
    for k, x, y, w, hh, t, kd in nodes:
        fl.node(k, x, y, w, hh, t, kd, 0, 19)
    for e in edges:
        fl.edge(*e[:4], text=(e[4] if len(e) > 4 else None))
    page(title, f'<div class="row" style="gap:30px;align-items:flex-start"><div style="width:960px;height:{h + 10}px">{fl.svg()}</div><div class="col" style="flex:1;gap:16px">{side}</div></div>', kicker, src)


agent_page("에이전트 ① 계획 읽기 · 여행사 접수 담당", "정해진 모양은 코드가 먼저 읽고, 나머지 줄만 AI가 원문 위치를 가리켜<br>근거 없는 값이 0입니다",
           [("in", 0, 30, 210, 90, "글 · 사진\nPDF · 워드 · 엑셀", "trig"),
            ("ocr", 260, 30, 210, 90, "사진은 한 줄씩\n그대로 받아쓰기", "proc"),
            ("rule", 520, 30, 220, 90, "정해진 모양은 코드가\n09:00 · 1일차 · 예약번호", "proc"),
            ("llm", 520, 190, 220, 110, "남은 줄만 AI가\n「몇 번째 글자부터」\n위치만 가리킴", "dec"),
            ("place", 260, 190, 210, 110, "장소 하나로 정하기\n우리 표 → 별칭 →\n오타 → 관광공사", "proc"),
            ("chk", 0, 350, 210, 90, "고객 확인 화면\n고치기 · 빼기", "agent"),
            ("out", 260, 350, 480, 90, "일정 등록 — 항목마다 값 · 방법 · 근거(원문 줄)", "out")],
           [("in", "ocr", "r", "l"), ("ocr", "rule", "r", "l"), ("rule", "llm", "b", "t"), ("llm", "place", "l", "r"), ("place", "chk", "l", "t"), ("chk", "out", "r", "l")],
           num("97.0", "%", "항목 재현율", "326/336 · 합성 평가셋 60건 · 1회차 90.2%")
           + num("0", "/1,828", "근거 없는 값")
           + num("3.4", "%", "값 변조 (목표 0 미달)", "사진 속 긴 가게 이름 오독 · 형식별 재현율 사진 91.2%", "warn"),
           "예: 「09:00 경복궁 관람」 → 「09:00」은 코드가 시각으로 읽고, 「경복궁 관람」은 AI가 위치만 가리킨 뒤 장소 표에서 경복궁으로 정한다.", 450)

agent_page("에이전트 ② 요식 · 맛집 컨시어지", "도착 시각에 식사가 성립하는지 먼저 계산하고,<br>안 되면 대신 갈 곳을 고릅니다",
           [("in", 0, 140, 210, 100, "식당 · 도착 시각\n머무는 시간", "trig"),
            ("chk", 260, 120, 240, 140, "요일별 영업시간\n브레이크 · 휴무\n라스트오더", "agent"),
            ("lo", 260, 310, 240, 110, "라스트오더 기준\n도착+20분이 넘으면 탈락\n모르면 60분 전 경고", "dec"),
            ("ok", 560, 20, 180, 70, "그대로 유지", "ghost"),
            ("alt", 560, 140, 200, 130, "대신할 곳 축별로\n덜 밀리는 곳\n비슷한 곳 · 가까운 곳", "proc"),
            ("out", 790, 140, 170, 130, "하나 먼저 적용\n나머지는\n「다른 안」", "out"),
            ("go", 560, 330, 400, 80, "이동 에이전트가 앞뒤 이동을 다시 계산", "agent")],
           [("in", "chk", "r", "l"), ("chk", "lo", "b", "t"), ("chk", "ok", "r", "l", "성립"), ("chk", "alt", "r", "l", "불성립"), ("alt", "out", "r", "l"), ("out", "go", "b", "t")],
           num("1,225", "곳", "서울 식당 목록", "관광공사 음식점 + 비건·할랄·미쉐린")
           + num("99", "/100", "영업시간 사람 대조 일치", "개선 전 87%")
           + '<div class="card warnc"><div class="t3 warn" style="font-size:22px">실시간 웨이팅 정보는 없음</div><div class="ns">공개 API가 없어 지도 링크로 확인. 낮 임시휴무를 스스로 찾는 기능은 다음 단계(지금은 고객 신고로)</div></div>',
           "자료 속 예시: 점심 70분 지연 → 브레이크타임에 걸림 → 도보 6분 식당으로.", 440)

agent_page("에이전트 ③ 액티비티 · 현지 가이드", "휴무·날씨로 못 가게 되면<br>같은 종류에서 가장 비슷한 활동부터 찾습니다",
           [("in", 0, 60, 210, 100, "활동 · 방문일\n날씨 · 대기질", "trig"),
            ("chk", 260, 50, 230, 120, "운영일 · 운영시간\n휴무 · 날씨 조건", "agent"),
            ("base", 260, 240, 230, 130, "같은 대분류는 유지\n(자연 · 인문 ·\n레포츠 · 쇼핑)", "dec"),
            ("p1", 540, 200, 230, 70, "1순위 소분류만 다른 곳", "proc"),
            ("p2", 540, 290, 230, 70, "2순위 중분류까지 다른 곳", "proc"),
            ("p3", 540, 380, 230, 70, "3순위 다른 구까지", "proc"),
            ("out", 810, 260, 150, 130, "대체 이유와\n함께 적용 ·\n안내", "out")],
           [("in", "chk", "r", "l"), ("chk", "base", "b", "t", "문제 있음"), ("base", "p1", "r", "l"), ("base", "p2", "r", "l"), ("base", "p3", "r", "l"), ("p1", "out", "r", "l"), ("p2", "out", "r", "l"), ("p3", "out", "r", "l")],
           num("805", "행", "서울 활동 후보", "관광공사 자연·인문·레포츠·쇼핑")
           + '<div class="card"><div class="t3" style="font-size:22px">자료 속 예시</div><div class="ns" style="color:#1d2a23">잠실 전망대 → 미세먼지·소나기 경보 → 실내 아쿠아리움</div></div>'
           + '<div class="card warnc"><div class="ns"><b class="warn">한계</b> — 추천이 알맞았는지 사람이 평가한 자료는 아직 없음</div></div>',
           "대체 우선순위는 팀 피그마 「액티비티 대체장소 우선순위 결정」.", 470)

agent_page("에이전트 ④ 이동 · 교통 안내원", "식당이나 활동이 바뀌면, 이동 판정기가 시간표로<br>앞뒤 이동을 다시 계산해야 확정됩니다",
           [("a", 0, 10, 220, 70, "일정을 처음 짤 때", "trig"), ("b", 0, 95, 220, 70, "식당이 바뀔 때 앞뒤", "trig"),
            ("c", 0, 180, 220, 70, "활동이 바뀔 때 앞뒤", "trig"), ("d", 0, 265, 220, 70, "운행 중단·무정차 뒤", "trig"),
            ("calc", 270, 90, 250, 170, "시간표 판정\n지하철·버스 46만 행\n역 출구 · 환승 도보\n따릉이 · 혼잡", "agent"),
            ("q", 570, 130, 150, 90, "제시간?", "dec"),
            ("ok", 770, 20, 190, 120, "성립\n출발 시각 · 경로 ·\n요금을 일정에", "out"),
            ("ng", 770, 200, 190, 120, "불가\n막차·배차 이유\n→ 다른 경로·시간", "fail"),
            ("grade", 270, 350, 690, 70, "모든 답에 근거 등급: 확정(시간표) · 추정(통계) · 근거 없음(말하지 않음)", "dec")],
           [("a", "calc", "r", "l"), ("b", "calc", "r", "l"), ("c", "calc", "r", "l"), ("d", "calc", "r", "l"), ("calc", "q", "r", "l"), ("q", "ok", "r", "l"), ("q", "ng", "r", "l")],
           num("168", "/168", "판정 회귀 시험 일치", "자동 생성 점검 12,032건")
           + '<div class="card"><div class="ns" style="color:#1d2a23">실제 채팅 답: 「09:04 출발 · 2호선 신대방→을지로3가 → 3호선 → 경복궁 · 약 62분 <b>(시간표 판정)</b>」</div></div>'
           + '<div class="card goldc"><div class="ns" style="color:#1d2a23">학습 모델(0.848)은 근거가 부족한 경우를 「성립」으로 바꿔 쓰지 않았습니다. <b>판정은 코드</b>.</div></div>',
           "팀 피그마 「이동 판정기 · 발표용」.", 430)

# 17 아키텍처 --------------------------------------------------------------------
ar = Flow(1440, 560)
ar.node("u1", 0, 60, 230, 80, "휴대폰 웹", "trig", 0, 22)
ar.node("u2", 0, 180, 230, 80, "여행계획서 링크", "trig", 0, 22)
ar.node("u3", 0, 300, 230, 80, "디스코드 알림", "trig", 0, 22)
ar.node("core", 330, 40, 420, 150, "여행 매니저(코어)\n분류 → 담당 고르기 → 판정 확인\n→ 일정 새 판 저장", "out", 0, 22)
for i, (k, t, x, w) in enumerate([("g1", "계획 읽기", 330, 130), ("g2", "요식", 475, 90), ("g3", "액티비티", 580, 110), ("g4", "이동", 705, 80)]):
    ar.node(k, x, 240, w, 90, t, "agent", 0, 20)
ar.node("loop", 330, 380, 455, 80, "상시 작업: 감시(1분마다) · 알림 배달", "proc", 0, 20)
ar.node("db", 860, 40, 260, 150, "데이터베이스\n여행 · 일정 판 · 사건\n식당 1,225 · 시간표 46만", "dec", 0, 20)
ar.node("ai", 860, 240, 260, 110, "로컬 AI\nGemma 4 12B · bge-m3", "dec", 0, 20)
ar.node("ext", 1180, 40, 250, 310, "외부 데이터\n관광공사\n카카오 · Google\n기상청 · 대기질\n재난문자 · 교통\n공휴일 · 공항", "ghost", 0, 20)
ar.edge("u1", "core"); ar.edge("u2", "core"); ar.edge("loop", "u3", "l", "r")
ar.edge("core", "g1", "b", "t"); ar.edge("core", "g4", "b", "t")
ar.edge("core", "db"); ar.edge("core", "ai", "r", "l"); ar.edge("db", "ext"); ar.edge("ai", "ext")
page("시스템은 사용자가 보는 곳, 매니저와 에이전트,<br>데이터와 AI의 세 층으로 동작합니다", f'<div style="height:570px">{ar.svg()}</div>', "시스템 아키텍처",
     "조회가 실패하면 다른 소스(예: 날씨 Open-Meteo ↔ 기상청, 교통 ITS ↔ UTIC)를 쓰고, 그것도 안 되면 조용히 넘기지 않는다.")

# 18 CI/CD --------------------------------------------------------------------
ci = Flow(1440, 470)
for i, (k, t) in enumerate([("f", "기능 브랜치"), ("r", "역할 브랜치\n매니저·액티비티\n요식·이동·평가"), ("d", "develop"), ("m", "main")]):
    ci.node(k, 20 + i * 360, 20, 250, 110, t, "agent" if k in "dm" else "proc", 0, 21)
for a, b in (("f", "r"), ("r", "d"), ("d", "m")):
    ci.edge(a, b, text="PR")
ci.node("g3", 380, 190, 300, 170, "웹 관문 (웹이 바뀔 때)\n린트·타입·단위·빌드\n→ 브라우저 e2e 시험", "dec", 0, 19)
ci.node("g1", 740, 190, 300, 170, "develop 관문\n린트\n+ DB 띄워 구조·계약·단위 시험\n1,015건", "dec", 0, 19)
ci.node("g2", 1100, 190, 320, 170, "main 관문\n구조 시험 먼저\n→ 전체 시험 1,400건\n→ Docker 빌드", "dec", 0, 19)
ci.edge("r", "g3", "b", "t"); ci.edge("d", "g1", "b", "t"); ci.edge("m", "g2", "b", "t")
ci.node("cd", 740, 395, 680, 64, "CD: 빌드까지 · 배포는 상시 운영을 약속하는 시점에", "ghost", 0, 19)
page("다섯 명이 한 코드에 올려도,<br>자동 관문이 시험 2,309건으로 먼저 막습니다",
     f'<div style="height:480px">{ci.svg()}</div><div class="quote gold"><b>관문이 잡은 사고</b> — GitHub 서버는 UTC라 시험 43건이 9시간 밀렸다(경복궁 09:00 → 00:00) → 서버·DB 시간대를 한국 시간으로 고정.</div>',
     "CI/CD · 협업", "전체 시험 2,309 통과·60 건너뜀(09-28). 이동 팀 PR 2건이 이 관문을 거쳐 develop에 합쳐졌다.")

# 19 평가 ---------------------------------------------------------------------
bars = [("계획 읽기 재현율", 90.2, 97.0, "같은 60건 · 코드 수정 뒤"), ("요식 영업시간 일치", 87.0, 99.0, "사람 대조 100곳"), ("대체 식당 분류 일치@3", 76.7, 91.5, "대리 지표 · 1회 · 제품 미적용")]
bh = "".join(f'<div style="margin-bottom:26px"><div class="t3" style="font-size:24px">{n} <span class="ns">· {c}</span></div>'
             f'<div class="bar"><i style="width:{a * 6}px;background:#c9cdc6"></i><b class="grayc">{a}%</b></div>'
             f'<div class="bar"><i style="width:{b * 6}px"></i><b class="hl">{b}%</b></div></div>' for n, a, b, c in bars)
lp = Flow(520, 460)
lp.node("s", 160, 0, 200, 80, "평가셋", "trig", 0, 22); lp.node("r", 340, 180, 170, 80, "실행", "proc", 0, 22)
lp.node("m", 160, 360, 200, 80, "지표(분자/분모)", "dec", 0, 20); lp.node("fx", 0, 180, 170, 80, "원인 고침", "agent", 0, 22)
lp.edge("s", "r", "r", "t"); lp.edge("r", "m", "b", "r"); lp.edge("m", "fx", "l", "b"); lp.edge("fx", "s", "t", "l")
page("같은 평가셋을 다시 돌려 개선을 수치로 확인하고,<br>정답이 없는 추천은 대리 지표와 사람 판정으로 봅니다",
     f'<div class="row" style="gap:50px;align-items:flex-start"><div style="width:520px;height:460px">{lp.svg()}</div><div style="flex:1">{bh}'
     '<div class="card"><div class="ns" style="color:#1d2a23">이동 판정 회귀 <b>168/168</b> · 분류 모델 기준 라벨 일치율 0.831·0.802(사람 정답 아님) · 대체 추천 사람 판정 시트 237행 작성 중</div></div></div></div>',
     "에이전트를 어떻게 평가하나")

# 20 트러블슈팅 ------------------------------------------------------------------
page("사진 일정표를 한 번에 읽히면 하루가 통째로 사라져,<br>받아쓰기와 해석을 나눴습니다",
     '''<div class="row" style="gap:28px;align-items:stretch">
 <div class="card warnc" style="flex:1"><span class="pill red">처음</span><div class="t3" style="margin:14px 0 6px">사진 → 일정 한 번에</div><div class="n warn">3<span>/6</span></div><div class="ns">일차 하나 통째 누락 · 원문에 없는 칸 추가</div></div>
 <div class="card" style="flex:1"><span class="pill blue">원인</span><div class="t3" style="margin:14px 0 6px">읽기와 해석을 한꺼번에</div><div class="ns" style="color:#1d2a23;font-size:22px">모델이 본 것과 지어낸 것이 섞여,<br>틀려도 어디서 틀렸는지 모른다</div></div>
 <div class="card" style="flex:1;border-color:#2d5f48"><span class="pill">바꾼 뒤</span><div class="t3" style="margin:14px 0 6px">한 줄씩 받아쓰기 → 코드가 읽기</div><div class="n hl">6<span>/6</span></div><div class="ns">값 변조 없음 · 두 번 받아써 빠진 줄 확인</div></div>
</div>
<div class="quote gold" style="margin-top:26px"><b>남은 문제</b> — 평가셋 60건에서 값 변조 3.4%(긴 가게 이름 오독). 다음: 두 번 받아쓴 결과가 다른 줄은 「확인 필요」로 표시.</div>''',
     "트러블슈팅 하나", "합성 사진 1장 · 시각 항목 6개 · 방식마다 1회 측정(설계서 2026-09-26)")

# 21 향후 ---------------------------------------------------------------------------
fut = [("요식", "낮 임시휴무를 스스로 찾기 · 대체 추천을 사람 판정으로 수치화"), ("액티비티", "추천이 알맞았는지 사람 평가 · 날씨·대기질 조건 확대"),
       ("이동", "실시간 도착 정보 · 택시 편입"), ("코어", "사람이 단 정답으로 계획 읽기·분류 평가 · 자체 분류 모델 18종 재학습 후 연결 검토")]
fc = "".join(f'<div class="card frow"><span class="pill">{a}</span><div>{b}</div></div>' for a, b in fut)
page("다음 한 달은 각 에이전트가<br>지금 못 하는 것을 하나씩 채웁니다", f'<div class="col" style="gap:16px">{fc}</div><p class="ns" style="margin-top:20px;font-size:19px">범위: 서울에서 검증을 마친 뒤 다른 도시로.</p>', "향후 계획")

# 22 정리 ----------------------------------------------------------------------------
P.append(f'''<section class="page cover"><div class="row" style="height:100%;align-items:center;gap:70px"><div style="flex:1">
<div class="kicker">정리</div><h1 style="font-size:62px">계획은 한 번 짜면 끝이 아니라<br>여행 내내 깨지고,<br><span class="hl">triPilot은 그때마다 지킵니다.</span></h1>
<div class="col" style="margin-top:36px;gap:12px;font-size:28px;font-weight:700"><div>올린다 — 쓰던 그대로, 근거 있는 값만</div><div>지킨다 — 요식·액티비티·이동이 다시 확인</div><div>알린다 — 먼저 고치고, 고를 수 있게</div></div>
<p class="lead" style="margin-top:40px">질문 받겠습니다.</p></div>{phone("s7_chat.jpg", w=250)}</div></section>''')

CSS = """
:root{--bg:#f5f3ec;--paper:#fffdf7;--ink:#1d2a23;--muted:#5f6b64;--line:#d9ddd3;--g1:#2d5f48;--g2:#3f7d61;--g3:#e5efe8;--gold:#c8913a;--gold2:#f6ead4;--red:#b8503a;--red2:#f6e3dc;--blue:#2f6c9a;--blue2:#e2eef7}
*{box-sizing:border-box;margin:0;padding:0}
body{background:#3a403c;font-family:Pretendard,"Malgun Gothic",sans-serif;color:var(--ink);-webkit-font-smoothing:antialiased}
.wrap{width:1600px;margin:0 auto;transform-origin:top left}
.page{position:relative;width:1600px;height:900px;background:var(--bg);padding:58px 80px;margin:0 0 28px;overflow:hidden}
.kicker{font-size:20px;letter-spacing:.14em;color:var(--g2);font-weight:700;margin-bottom:12px}
h1{font-size:72px;line-height:1.15;font-weight:800;letter-spacing:-.02em}
h2{font-size:40px;line-height:1.28;font-weight:800;letter-spacing:-.015em;margin-bottom:30px}
.lead{font-size:28px;color:var(--muted);margin-top:28px}
.hl{color:var(--g1)} .warn{color:var(--red)} .grayc{color:#9aa39d}
.row{display:flex} .col{display:flex;flex-direction:column}
.card{background:var(--paper);border:1px solid var(--line);border-radius:20px;padding:24px 28px}
.card.dark{background:var(--g1);color:#fff;border:none}
.card.warnc{border-color:var(--red);background:var(--red2)} .card.goldc{background:var(--gold2);border-color:#e7c98f}
.card.mini{width:300px;margin-top:30px}
.pill{display:inline-block;padding:5px 14px;border-radius:999px;font-size:18px;font-weight:700;background:var(--g3);color:var(--g1)}
.pill.red{background:#fff;color:var(--red)} .pill.blue{background:var(--blue2);color:var(--blue)}
.t3{font-size:30px;font-weight:800}
.ns{font-size:18px;color:var(--muted);line-height:1.55}
.q{font-size:20px;font-weight:800;color:var(--g2);margin-bottom:8px}
.numc .n,.n{font-size:64px;font-weight:800;letter-spacing:-.02em;line-height:1;color:var(--g1);font-variant-numeric:tabular-nums}
.n span{font-size:30px} .n.warn{color:var(--red)} .n.grayc{color:#9aa39d}
.numc .nl{font-size:22px;font-weight:800;margin-top:10px} .numc .ns{margin-top:4px}
.chain{display:flex;align-items:stretch;gap:0;margin-top:20px}
.chain .link{flex:1;background:var(--paper);border:1px solid var(--line);border-radius:20px;padding:26px 24px}
.arw{display:flex;align-items:center;font-size:44px;color:var(--gold);padding:0 10px;font-weight:800}
.say{font-size:30px;margin-top:40px;line-height:1.5}
.nine{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:10px}
.st{background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:14px 18px;font-size:23px;font-weight:700;display:flex;gap:12px;align-items:center}
.st b{color:var(--gold);font-size:26px}
.timeline{display:flex;gap:24px;position:relative}
.timeline:before{content:"";position:absolute;left:0;right:0;top:96px;height:4px;background:var(--line)}
.tl{flex:1;position:relative}.tt{font-size:20px;font-weight:700;color:var(--muted)}.tp{font-size:30px;font-weight:800;margin-top:4px}
.dot{width:18px;height:18px;border-radius:50%;background:var(--g1);margin:18px 0 22px;position:relative}
.ev{background:var(--red2);border:1px solid var(--red);border-radius:16px;padding:16px 18px}.ev.ok{background:var(--g3);border-color:var(--g3)}.evt{font-size:24px;font-weight:800;color:var(--red)}
.f3{flex:1;display:flex;flex-direction:column;align-items:center;text-align:center;gap:10px}.t3{text-align:inherit}.d3{font-size:22px;font-weight:600;line-height:1.45;min-height:64px}
.ph{display:flex;flex-direction:column;align-items:center;gap:10px}
.phone{border-radius:36px;background:#111;padding:9px;box-shadow:0 10px 24px rgba(0,0,0,.18)}
.phone img{width:100%;height:100%;object-fit:cover;object-position:top;border-radius:28px;display:block}
.cap{font-size:19px;font-weight:700;text-align:center;line-height:1.45}
.cmp{width:100%;border-collapse:separate;border-spacing:0 8px;font-size:21px}
.cmp th{text-align:left;color:var(--muted);font-size:18px;padding:0 18px}.cmp td{padding:16px 18px;background:var(--paper)}
.cmp td:first-child{font-weight:800;font-size:24px;border-radius:14px 0 0 14px}.cmp td:last-child{border-radius:0 14px 14px 0;font-weight:700}
.cmp tr.me td{background:var(--g1);color:#fff}
.quote{margin-top:20px;background:var(--paper);border:1px solid var(--line);border-radius:16px;padding:18px 24px;font-size:21px;line-height:1.55}.quote.gold{background:var(--gold2);border-color:#e7c98f}
.bar{display:flex;align-items:center;gap:12px;margin-top:8px}.bar i{display:block;height:22px;background:var(--g2);border-radius:5px}.bar b{font-size:22px}
.frow{display:flex;gap:30px;align-items:center;padding:28px 34px;font-size:30px;font-weight:600}.frow .pill{min-width:150px;text-align:center;font-size:24px;padding:8px 16px}
.src{position:absolute;left:80px;right:80px;bottom:26px;font-size:15px;color:#8a938d;line-height:1.5}
svg text{font-family:Pretendard,"Malgun Gothic",sans-serif}
.edge{fill:none;stroke:#8fa197;stroke-width:3}
.pn{position:absolute;right:40px;top:26px;font-size:15px;color:#9aa39d}
@media print{body{background:#fff}.page{margin:0;page-break-after:always;break-after:page}.wrap{transform:none!important}}
@page{size:1600px 900px;margin:0}
"""
pages = "\n".join(p.replace("</section>", f'<div class="pn">{i + 1} / {len(P)}</div></section>', 1) for i, p in enumerate(P))
html = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>triPilot 멘토 발표 v2</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css">
<style>{CSS}</style></head><body><div class="wrap" id="w">{pages}</div>
<script>/* 화면 폭에 맞춰 크기만 맞춘다(움직임 없음) */(function(){{var w=document.getElementById('w');function f(){{if(matchMedia('print').matches)return;var k=Math.min(1,(innerWidth-20)/1600);w.style.transform='scale('+k+')';w.style.marginLeft=Math.max(10,(innerWidth-1600*k)/2)+'px';document.body.style.height=(w.scrollHeight*k+20)+'px'}}addEventListener('resize',f);f()}})();</script>
</body></html>"""
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(html, encoding="utf-8")
print("페이지", len(P), "장 →", OUT)
