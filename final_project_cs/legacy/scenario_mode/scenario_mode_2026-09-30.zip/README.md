# 시나리오(시연) 모드 — 운영 앱에서 떼어 보관 (2026-09-30)

사용자 지시: 「시연(시나리오) 모드가 운영 앱 안에 있다 — 실서비스 운영 화면과 데모가 같은 프로세스라서 배포 전에 떼는 편이 안전하다.
압축파일로 만들어서 떼어놔.」 (결정 기록 D-CS-008 「다음 순서 2」 — 시나리오 데모를 운영 앱에서 뗀다)

## 무엇이었나
확정 시나리오 하루(대만 친구들 서울 하루)를 **실제 시스템으로 돌려 보이는 데모 모드**. 한 판을 프로세스 메모리에 들고 있어
아래 셋이 같은 프로세스에 있어야 했다.
- 스위치 화면 `/ui/scenario` (운영 화면 메뉴 「Scenario」)
- 시연 화면 `/tripilot` (사용자 화면 흉내)
- 시나리오 입구 `/scenario/status|start|stop|feed|ops|next|message|alternate` — 설정 `scenario_mode_enabled` 가 꺼져 있으면 404

## 이 압축파일에 든 것 (저장소 기준 경로 그대로)
- `app/modules/travel_ops/scenario_mode.py` — 본체(ScenarioSession · 장면 · 입구)
- `app/modules/travel_ops/static/tripilot.html` — 시연 화면
- `app/modules/travel_ops/scenarios/seoul_day_taiwan_friends.json` — 대본 사본 ★원본은 저장소에 그대로 남아 있다(시험 여럿이 경로로 직접 읽는다)
- `tests/e2e/test_scenario_mode.py` — 시연 모드 시험
- `_removed_from_ui_routes.py.txt` — `app/presentation/ui/routes.py` 에서 뺀 `scenario_switch` 함수(스위치 화면) 원문
- `README.md` — 이 문서

## 저장소에서 바꾼 곳 (되돌릴 때 이 다섯 곳을 원래대로)
1. `app/composition.py` `build_ops_routers()` — `build_scenario_router(...)` 를 반환 목록에 다시 넣는다
2. `app/presentation/ui/routes.py` — `_removed_from_ui_routes.py.txt` 를 `@router.get("/admin"...)` 앞에 붙인다
3. `app/presentation/ui/theme.py` `NAV` — `("/ui/scenario", "Scenario")` 를 `/ui/admin` 앞에 다시 넣는다
4. `app/presentation/ui/__init__.py` — `HOST_LANDINGS = {"tripilot": "/tripilot", "scenario": "/ui/scenario"}` 와 루트 리다이렉트의 이름 분기
5. 시험 — `tests/architecture/test_ops_app_is_separate.py` · `tests/contract/test_every_screen_is_reachable.py` 의 시연 경로 기대, `tests/e2e/test_route_uses_contract.py` 의 `SCENARIO_PATH`
   그리고 압축파일의 파일들을 위 경로에 풀어 넣는다.
- 설정 `scenario_mode_enabled`(`app/core/settings.py`)는 **지우지 않았다** — 설정 검사가 모르는 이름을 거부(`extra="forbid"`)해서, 옛 `.env` 가
  이 이름을 적고 있으면 앱이 못 뜬다. 지금은 아무 일도 안 하는 자리표시다.

## 저장소 기록으로도 복원된다
떼기 직전 커밋: `26338a10 docs(research): LatWeave(arXiv 2609.27225) 확인 — 구조 조회·구조적 기권은 우리 방향과 같고 자유 문장에서는 성능이 크게 떨어진다`
```
git show <그 커밋>:final_project_cs/app/modules/travel_ops/scenario_mode.py
```

## 다시 쓸 때 (권장)
운영 앱에 되붙이지 말고 **별도 데모 앱(127.0.0.1, 다른 포트)** 으로 세운다 — 운영 화면과 같은 프로세스에 두면 뗀 이유가 사라진다.
대본 데이터(`seoul_day_taiwan_friends.json`)는 시험 · `scripts/replay_scenario.py` · `eval/runners/travel_scenarios.py` 가 계속 쓴다.
